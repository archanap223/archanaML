use assignment;

# Creating temp tables for Date conversion

create table tempbajaj 
as
select Date,`Close Price` ClosePrice, str_to_date(Date,"%d-%M-%Y") Date1
from `bajaj auto`;

create table tempeicher 
as
select Date,`Close Price` ClosePrice, str_to_date(Date,"%d-%M-%Y") Date1
from `eicher motors`;

create table temphero 
as
select Date,`Close Price` ClosePrice, str_to_date(Date,"%d-%M-%Y") Date1
from `hero motocorp`;

create table tempinfosys 
as
select Date,`Close Price` ClosePrice, str_to_date(Date,"%d-%M-%Y") Date1
from `infosys`;

create table temptcs 
as
select Date,`Close Price` ClosePrice, str_to_date(Date,"%d-%M-%Y") Date1
from `tcs`;

create table temptvs 
as
select Date,`Close Price` ClosePrice, str_to_date(Date,"%d-%M-%Y") Date1
from `tvs motors`;

# Question 1
# Create a new table named 'bajaj1' containing the date, close price, 20 Day MA and 50 Day MA. (This has to be done for all 6 stocks)
create table bajaj1 
as
SELECT Date1 Date,
       ClosePrice,
       ROW_NUMBER() OVER (ORDER BY Date1 ASC) RowNumber,
       AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 19 PRECEDING) AS MA20D,
	  AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 49 PRECEDING) AS MA50D
FROM   tempbajaj;

create table eichermotors1
as
SELECT Date1 Date,
       ClosePrice,
       ROW_NUMBER() OVER (ORDER BY Date1 ASC) RowNumber,
       AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 19 PRECEDING) AS MA20D,
	  AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 49 PRECEDING) AS MA50D
FROM   tempeicher;

create table heromotocorp1
as
SELECT Date1 Date,
       ClosePrice,
       ROW_NUMBER() OVER (ORDER BY Date1 ASC) RowNumber,
       AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 19 PRECEDING) AS MA20D,
	  AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 49 PRECEDING) AS MA50D
FROM   temphero;

create table infosys1
as
SELECT Date1 Date,
       ClosePrice,
       ROW_NUMBER() OVER (ORDER BY Date1 ASC) RowNumber,
       AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 19 PRECEDING) AS MA20D,
	  AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 49 PRECEDING) AS MA50D
FROM   tempinfosys;

create table tcs1
as
SELECT Date1 Date,
       ClosePrice,
       ROW_NUMBER() OVER (ORDER BY Date1 ASC) RowNumber,
       AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 19 PRECEDING) AS MA20D,
	  AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 49 PRECEDING) AS MA50D
FROM   temptcs;


create table tvsmotors1
as
SELECT Date1 Date,
       ClosePrice,
       ROW_NUMBER() OVER (ORDER BY Date1 ASC) RowNumber,
       AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 19 PRECEDING) AS MA20D,
	  AVG(ClosePrice) OVER (ORDER BY Date1 ASC ROWS 49 PRECEDING) AS MA50D
FROM   temptvs;

# Question 2
# Create a master table containing the date and close price of all the six stocks. (Column header for the price is the name of the stock)

create table stock_master
as
select b.Date, 
	   b.ClosePrice "Bajaj", 
       e.ClosePrice "Eicher",
       h.ClosePrice "Hero",
       i.ClosePrice "Infosys",
       tcs.ClosePrice "TCS",
       tvs.ClosePrice "TVS"
from bajaj1 b, eichermotors1 e, heromotocorp1 h, infosys1 i, tcs1 tcs, tvsmotors1 tvs
where b.Date = e.Date and e.Date = h.Date and h.Date = b.Date 
and h.Date = i.Date and i.Date = tcs.Date and tcs.Date = tvs.Date
and b.Date = i.Date and b.Date = tcs.Date and b.Date = tvs.Date
and e.Date = i.Date and e.Date = tcs.Date and e.Date = tvs.Date
and h.Date = tcs.Date and h.Date = tvs.Date and i.Date = tvs.Date;

select * from stock_master;

select * from bajaj1;

# Delete the temporary tables, since will be created 
drop table tempbajaj;

drop table tempeicher;

drop table temphero;

drop table tempinfosys;

drop table temptcs;

drop table temptvs;

# Question 3
# Use the table created in Part(1) to generate buy and sell signal. 
# Store this in another table named 'bajaj2'. Perform this operation for all stocks.


# Creating tables for storing the  diff in 20 and 50 Day Average for current day and previous day
# Create table for each stock with Signal identified for each date

create table tempbajaj
as
select Date, 
	   ClosePrice,
       RowNumber,
       MA20D,
       MA50D,
       (MA20D-MA50D) MA_Diff_CurrDay,
       (LAG(MA20D,1) OVER (ORDER BY Date) - LAG(MA50D,1) OVER (ORDER BY Date)) MA_Diff_PrevDay
from bajaj1
order by Date;     

select * from tempbajaj  ;

create table bajaj2
as
select Date, 
	   ClosePrice,
       CASE
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay > 0 AND MA_Diff_PrevDay < 0) THEN 'Buy'
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay < 0 AND MA_Diff_PrevDay > 0) THEN 'Sell'
          ELSE 'HOLD'
       END as `Signal`
FROM   tempbajaj
order by Date; 

create table tempeicher
as
select Date, 
	   ClosePrice,
       RowNumber,
       MA20D,
       MA50D,
       (MA20D-MA50D) MA_Diff_CurrDay,
       (LAG(MA20D,1) OVER (ORDER BY Date) - LAG(MA50D,1) OVER (ORDER BY Date)) MA_Diff_PrevDay
from eichermotors1
order by Date;     

select * from tempeicher  ;

create table eichermotors2
as
select Date, 
	   ClosePrice,
       CASE
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay > 0 AND MA_Diff_PrevDay < 0) THEN 'Buy'
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay < 0 AND MA_Diff_PrevDay > 0) THEN 'Sell'
          ELSE 'HOLD'
       END as `Signal`
FROM   tempeicher
order by Date; 

select `signal`, count(*)
from eichermotors2
group by `signal`;


create table temphero
as
select Date, 
	   ClosePrice,
       RowNumber,
       MA20D,
       MA50D,
       (MA20D-MA50D) MA_Diff_CurrDay,
       (LAG(MA20D,1) OVER (ORDER BY Date) - LAG(MA50D,1) OVER (ORDER BY Date)) MA_Diff_PrevDay
from heromotocorp1
order by Date;     

select * from temphero  ;

create table heromotors2
as
select Date, 
	   ClosePrice,
       CASE
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay > 0 AND MA_Diff_PrevDay < 0) THEN 'Buy'
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay < 0 AND MA_Diff_PrevDay > 0) THEN 'Sell'
          ELSE 'HOLD'
       END as `Signal`
FROM   temphero
order by Date; 

select `signal`, count(*)
from heromotors2
group by `signal`;

create table tempinfosys
as
select Date, 
	   ClosePrice,
       RowNumber,
       MA20D,
       MA50D,
       (MA20D-MA50D) MA_Diff_CurrDay,
       (LAG(MA20D,1) OVER (ORDER BY Date) - LAG(MA50D,1) OVER (ORDER BY Date)) MA_Diff_PrevDay
from infosys1
order by Date;     

select * from tempinfosys  ;

create table infosys2
as
select Date, 
	   ClosePrice,
       CASE
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay > 0 AND MA_Diff_PrevDay < 0) THEN 'Buy'
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay < 0 AND MA_Diff_PrevDay > 0) THEN 'Sell'
          ELSE 'HOLD'
       END as `Signal`
FROM   tempinfosys
order by Date; 

select `signal`, count(*)
from infosys2
group by `signal`;

create table temptcs
as
select Date, 
	   ClosePrice,
       RowNumber,
       MA20D,
       MA50D,
       (MA20D-MA50D) MA_Diff_CurrDay,
       (LAG(MA20D,1) OVER (ORDER BY Date) - LAG(MA50D,1) OVER (ORDER BY Date)) MA_Diff_PrevDay
from tcs1
order by Date;     

select * from temptcs  ;

create table tcs2
as
select Date, 
	   ClosePrice,
       CASE
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay > 0 AND MA_Diff_PrevDay < 0) THEN 'Buy'
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay < 0 AND MA_Diff_PrevDay > 0) THEN 'Sell'
          ELSE 'HOLD'
       END as `Signal`
FROM   temptcs
order by Date; 

select `signal`, count(*)
from tcs2
group by `signal`;

create table temptvs
as
select Date, 
	   ClosePrice,
       RowNumber,
       MA20D,
       MA50D,
       (MA20D-MA50D) MA_Diff_CurrDay,
       (LAG(MA20D,1) OVER (ORDER BY Date) - LAG(MA50D,1) OVER (ORDER BY Date)) MA_Diff_PrevDay
from tvsmotors1
order by Date;     

select * from temptvs  ;

create table tvsmotors2
as
select Date, 
	   ClosePrice,
       CASE
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay > 0 AND MA_Diff_PrevDay < 0) THEN 'Buy'
          WHEN (RowNumber > 49 AND MA_Diff_CurrDay < 0 AND MA_Diff_PrevDay > 0) THEN 'Sell'
          ELSE 'HOLD'
       END as `Signal`
FROM   temptvs
order by Date; 

select `signal`, count(*)
from tvsmotors2
group by `signal`;

# Question 4
# Create a User defined function, that takes the date as input and returns the signal for that particular day (Buy/Sell/Hold) for the Bajaj stock.
DELIMITER $$
CREATE FUNCTION getSignal(inDate DateTime)
RETURNS VARCHAR(10) DETERMINISTIC
BEGIN
	Declare retSig varchar(10);
    
    select `signal` into retSig 
    from bajaj2
    where Date = inDate;
    
    RETURN retSig;
END;
$$

DELIMITER ;

# Running the function 
select getSignal(Date) 
from bajaj2;

# Analysis
select 'Bajaj', max(ClosePrice)/min(ClosePrice) from bajaj1
UNION
select 'Eicher', max(ClosePrice)/min(ClosePrice) from eichermotors1
UNION
select 'Hero', max(ClosePrice)/min(ClosePrice) from heromotocorp1
UNION
select 'Infosys', max(ClosePrice)/min(ClosePrice) from infosys1
UNION
select 'TCS', max(ClosePrice)/min(ClosePrice) from tcs1
UNION
select 'TVS', max(ClosePrice)/min(ClosePrice) from tvsmotors1;
